package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {
private Customer customer;

@RequestMapping(value= {"/","index"})
public String getIndexPage() {
	return "indexpage";
}


}
