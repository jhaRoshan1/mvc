package com.cg.billing.aspects;

public class BillingExceptionAspect {

}
